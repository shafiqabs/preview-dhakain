
<?php $this->load->view('layouts/header.php') ?>
<?php echo $content_for_layout; ?>
<?php $this->load->view('layouts/footer.php') ?>



