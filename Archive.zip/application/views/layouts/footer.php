<!-- Footer -->
<footer class="clearfix">

    <div class="innerfooter container">
        <article class="about span5 clearfix" >
            <h2>About Us</h2>
            <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem</p>
            <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem</p>
            <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem</p>
        </article>

        <article class="span3 clearfix">
            <h2>Our Visitor Gallery</h2>
            <div class="flicker-images">

                <a href="#">
                    <img alt="" src="/assets/images/footer-photo.jpg">
                </a>
                <a href="#">
                    <img alt="" src="/assets/images/footer-photo.jpg">
                </a>
                <a href="#">
                    <img alt="" src="/assets/images/footer-photo.jpg">
                </a>

                <a href="#">
                    <img alt="" src="/assets/images/footer-photo.jpg">
                </a>
                <a href="#">
                    <img alt="" src="/assets/images/footer-photo.jpg">
                </a>
                <a href="#">
                    <img alt="" src="/assets/images/footer-photo.jpg">
                </a>

            </div>
        </article>


        <article class="contact-info span4 clearfix">
            <h2>Contact info</h2>
            <p><img alt="" src="/assets/images/con-info1.png"><span>+880 182 148 148</span></p>
            <p><img alt="" src="/assets/images/con-info1.png"><span>+8802 148 1488</span></p>
            <p><img alt="" src="/assets/images/con-info2.png"><span><a target="_blank" href="info@reservation.com">info@reservation.com</a></span></p>
            <p><img alt="" src="/assets/images/con-info3.png"><span>+8802 148 1489</span></p>
            <p><img alt="" src="/assets/images/con-info4.png"><span>7/9 Gulshan Avenue , Gulshan
					Dhaka 1201 , Bangladesh</span></p>
        </article>
    </div>
    <div class="end">
        <div class="back-to-top">
            <img alt="" src="/assets/images/back-to-top.png">
            <p>Registered in Bangladesh. Company registration number: 233462. VAT no: GB232457280 <br/>&copy; Copyright Reserved By Reservationin Private Limited</p>
        </div>
    </div>


</footer>
<!-- End Footer -->

</div>
<!-- End Container -->

<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/assets/js/jquery.cookie.js"></script>
<script src="/assets/js/jquery.ticker.js" type="text/javascript"></script>
<script type="text/javascript" src="/assets/js/jquery.superfish.js"></script>
<script type="text/javascript" src="/assets/js/jquery.selectbox.min.js"></script>
<!--<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>-->
<script type="text/javascript" src="/assets/js/gmap3.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.fancybox.js"></script>
<script type="text/javascript" src="/assets/js/jquery.cookie.js"></script>
<script defer src="/assets/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="/assets/plugins/bxslider/jquery.bxslider.js"></script>

<link rel="stylesheet" href="/assets/plugins/jquery/css/select.css" type="text/css">
<link rel="stylesheet" type="text/css" href="/assets/plugins/jquery/css/jquery.datetimepicker.css" />


<script type="text/javascript" src="/assets/plugins/jquery/js/jquery.datetimepicker.js"></script>
<script type="text/javascript" src="/assets/plugins/jquery/js/jquery.custom-select.min.js"></script>
<link href="/assets/plugins/jquery/css/rlchecked.css" rel="stylesheet">
<script type="text/javascript" src="/assets/plugins/jquery/js/rlchecked.min.js"></script>
<script type="text/javascript" src="/assets/plugins/jquery/js/jquery.innerfade.js"></script>
<script src="/assets/js/app.js"></script>
<script src="/assets/js/script.js"></script>

</body>
</html>